package com.railway.userservice.service;

import com.railway.userservice.dto.LoginRequestDTO;
import com.railway.userservice.dto.UserRequestDTO;
import com.railway.userservice.dto.UserResponseDTO;
import com.railway.userservice.entity.User;
import com.railway.userservice.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    // Convert Entity → ResponseDTO
    private UserResponseDTO convertToResponseDTO(User user) {
        UserResponseDTO dto = new UserResponseDTO();
        dto.setUserId(user.getUserId());
        dto.setName(user.getName());
        dto.setAge(user.getAge());
        dto.setAddress(user.getAddress());
        dto.setEmail(user.getEmail());
        dto.setPhone(user.getPhone());
        dto.setGender(user.getGender());
        dto.setRole(user.getRole());
        return dto;
    }

    // Convert RequestDTO → Entity
    private User convertToEntity(UserRequestDTO dto) {
        User user = new User();
        user.setName(dto.getName());
        user.setAge(dto.getAge());
        user.setAddress(dto.getAddress());
        user.setEmail(dto.getEmail());
        user.setPassword(dto.getPassword());
        user.setPhone(dto.getPhone());
        user.setGender(dto.getGender());
        return user;
    }

    //  Register
    public UserResponseDTO registerUser(UserRequestDTO requestDTO) {
        if (userRepository.existsByEmail(requestDTO.getEmail())) {
            throw new RuntimeException("Email already registered!");
        }
        User user = convertToEntity(requestDTO);
        user.setRole("PASSENGER");
        User savedUser = userRepository.save(user);
        return convertToResponseDTO(savedUser);
    }

    //  Login
    public UserResponseDTO loginUser(LoginRequestDTO loginDTO) {
        User user = userRepository.findByEmail(loginDTO.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found!"));

        if (!user.getPassword().equals(loginDTO.getPassword())) {
            throw new RuntimeException("Invalid password!");
        }
        return convertToResponseDTO(user);
    }

    //  Get by ID
    public UserResponseDTO getUserById(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found!"));
        return convertToResponseDTO(user);
    }



    // Update User
    public UserResponseDTO updateUser(Long id, UserRequestDTO requestDTO) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found!"));

        user.setName(requestDTO.getName());
        user.setAge(requestDTO.getAge());
        user.setAddress(requestDTO.getAddress());
        user.setPhone(requestDTO.getPhone());
        user.setGender(requestDTO.getGender());

        User updatedUser = userRepository.save(user);
        return convertToResponseDTO(updatedUser);
    }

    //  Delete User
    public String deleteUser(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found!"));
        userRepository.delete(user);
        return "User deleted successfully!";
    }


}