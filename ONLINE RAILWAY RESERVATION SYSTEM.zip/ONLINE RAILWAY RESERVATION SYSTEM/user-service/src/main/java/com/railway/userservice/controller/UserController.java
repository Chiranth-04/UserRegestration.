package com.railway.userservice.controller;

import com.railway.userservice.dto.LoginRequestDTO;
import com.railway.userservice.dto.UserRequestDTO;
import com.railway.userservice.dto.UserResponseDTO;
import com.railway.userservice.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;


    @PostMapping("/register")
    public UserResponseDTO register(@RequestBody UserRequestDTO requestDTO) {
        return userService.registerUser(requestDTO);
    }


    @PostMapping("/login")
    public UserResponseDTO login(@RequestBody LoginRequestDTO loginDTO) {
        return userService.loginUser(loginDTO);
    }


    @GetMapping("/{id}")
    public UserResponseDTO getUser(@PathVariable Long id) {
        return userService.getUserById(id);
    }


    @PutMapping("/update/{id}")
    public UserResponseDTO updateUser(
            @PathVariable Long id,
            @RequestBody UserRequestDTO requestDTO) {
        return userService.updateUser(id, requestDTO);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteUser(@PathVariable Long id) {
        return userService.deleteUser(id);
    }
}