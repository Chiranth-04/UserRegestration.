package com.railway.bookingservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

// This is copy of Train Service Response
// Used by Feign Client to receive train data
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TrainResponseDTO {

    private Long trainId;
    private String trainName;
    private String source;
    private String destination;
    private String departureTime;
    private String arrivalTime;
    private String status;
    private List<TrainClassDTO> trainClasses;
}