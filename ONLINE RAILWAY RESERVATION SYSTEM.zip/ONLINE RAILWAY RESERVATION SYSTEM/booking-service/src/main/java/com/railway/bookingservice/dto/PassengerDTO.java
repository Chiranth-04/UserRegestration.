package com.railway.bookingservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PassengerDTO {

    private Long passengerId;
    private String passengerName;
    private int passengerAge;
    private String passengerGender;
    private String seatNumber;
}