package com.railway.bookingservice.feignclient;

import com.railway.bookingservice.dto.TrainResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

// name must match spring.application.name
// of Train Service
@FeignClient(name = "TRAIN-SERVICE")
public interface TrainServiceClient {

    // Get train details
    @GetMapping("/api/trains/{id}")
    TrainResponseDTO getTrainById(@PathVariable Long id);

    // Check seat availability
    @GetMapping("/api/trains/availability/{trainId}")
    boolean checkAvailability(
            @PathVariable Long trainId,
            @RequestParam String className);

    // Get fare by class
    @GetMapping("/api/trains/fare/{trainId}")
    double getFare(
            @PathVariable Long trainId,
            @RequestParam String className);

    // Update seat count after booking
    @PutMapping("/api/trains/update-seats/{trainId}")
    String updateSeatCount(
            @PathVariable Long trainId,
            @RequestParam String className,
            @RequestParam int count);
}