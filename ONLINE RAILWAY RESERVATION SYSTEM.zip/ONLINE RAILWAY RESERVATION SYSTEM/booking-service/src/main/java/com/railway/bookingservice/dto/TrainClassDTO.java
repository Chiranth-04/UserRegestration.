package com.railway.bookingservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TrainClassDTO {

    private Long classId;
    private String className;
    private double fare;
    private int totalSeats;
    private int availableSeats;
}