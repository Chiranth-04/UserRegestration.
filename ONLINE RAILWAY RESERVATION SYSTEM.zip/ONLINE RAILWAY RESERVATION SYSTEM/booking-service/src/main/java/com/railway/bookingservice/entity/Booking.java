package com.railway.bookingservice.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "bookings")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long bookingId;

    // Auto generated unique PNR
    @Column(unique = true, nullable = false)
    private String pnrNumber;

    // User who booked
    @Column(nullable = false)
    private Long userId;

    // Train details
    @Column(nullable = false)
    private Long trainId;

    @Column(nullable = false)
    private String trainName;

    @Column(nullable = false)
    private String source;

    @Column(nullable = false)
    private String destination;

    @Column(nullable = false)
    private String departureTime;

    // Class selected
    @Column(nullable = false)
    private String className;

    // Journey date
    @Column(nullable = false)
    private LocalDate journeyDate;

    // Booking date
    @Column(nullable = false)
    private LocalDate bookingDate;

    // Seat info
    @Column(nullable = false)
    private int numberOfSeats;

    @Column(nullable = false)
    private double farePerSeat;

    @Column(nullable = false)
    private double totalFare;

    // CONFIRMED, CANCELLED, PENDING
    @Column(nullable = false)
    private String bookingStatus;

    // Passenger list
    @OneToMany(mappedBy = "booking",
            cascade = CascadeType.ALL,
            fetch = FetchType.EAGER)
    private List<Passenger> passengers;
}