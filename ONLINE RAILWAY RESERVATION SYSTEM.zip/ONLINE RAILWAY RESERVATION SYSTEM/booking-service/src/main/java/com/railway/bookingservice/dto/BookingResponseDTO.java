package com.railway.bookingservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookingResponseDTO {

    private Long bookingId;
    private String pnrNumber;
    private Long userId;
    private Long trainId;
    private String trainName;
    private String source;
    private String destination;
    private String departureTime;
    private String className;
    private LocalDate journeyDate;
    private LocalDate bookingDate;
    private int numberOfSeats;
    private double farePerSeat;
    private double totalFare;
    private String bookingStatus;
    private List<PassengerDTO> passengers;
}