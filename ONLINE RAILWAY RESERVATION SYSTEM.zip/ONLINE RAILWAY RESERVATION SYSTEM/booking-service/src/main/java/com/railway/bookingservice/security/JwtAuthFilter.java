package com.railway.bookingservice.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication
        .UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority
        .SimpleGrantedAuthority;
import org.springframework.security.core.context
        .SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter
        .OncePerRequestFilter;

import java.io.IOException;
import java.util.List;

@Component
public class JwtAuthFilter
        extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain)
            throws ServletException, IOException {

        // ✅ Read headers from API Gateway
        String userEmail = request
                .getHeader("X-User-Email");
        String userRole = request
                .getHeader("X-User-Role");

        // ✅ Set authentication
        if (userEmail != null
                && userRole != null) {
            SimpleGrantedAuthority authority =
                    new SimpleGrantedAuthority(
                            "ROLE_" + userRole);

            UsernamePasswordAuthenticationToken
                    authToken =
                    new UsernamePasswordAuthenticationToken(
                            userEmail,
                            null,
                            List.of(authority));

            SecurityContextHolder
                    .getContext()
                    .setAuthentication(authToken);
        }
        filterChain.doFilter(request, response);
    }
}