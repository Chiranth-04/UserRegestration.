package com.railway.bookingservice.repository;

import com.railway.bookingservice.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BookingRepository
        extends JpaRepository<Booking, Long> {

    // Find booking by PNR
    Optional<Booking> findByPnrNumber(String pnrNumber);

    // Find all bookings by user
    List<Booking> findByUserId(Long userId);

    // Find all bookings by train
    List<Booking> findByTrainId(Long trainId);
}