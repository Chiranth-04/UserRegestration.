package com.railway.bookingservice.service;

import com.railway.bookingservice.dto.*;
import com.railway.bookingservice.entity.Booking;
import com.railway.bookingservice.entity.Passenger;
import com.railway.bookingservice.feignclient.TrainServiceClient;
import com.railway.bookingservice.repository.BookingRepository;
import com.railway.bookingservice.repository.PassengerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BookingService {

    private final BookingRepository bookingRepository;
    private final PassengerRepository passengerRepository;
    private final TrainServiceClient trainServiceClient;

    //  Convert Passenger Entity → DTO
    private PassengerDTO toPassengerDTO(Passenger passenger) {
        PassengerDTO dto = new PassengerDTO();
        dto.setPassengerId(passenger.getPassengerId());
        dto.setPassengerName(passenger.getPassengerName());
        dto.setPassengerAge(passenger.getPassengerAge());
        dto.setPassengerGender(passenger.getPassengerGender());
        dto.setSeatNumber(passenger.getSeatNumber());
        return dto;
    }

    //  Convert Booking Entity → ResponseDTO
    private BookingResponseDTO toResponseDTO(Booking booking) {
        BookingResponseDTO dto = new BookingResponseDTO();
        dto.setBookingId(booking.getBookingId());
        dto.setPnrNumber(booking.getPnrNumber());
        dto.setUserId(booking.getUserId());
        dto.setTrainId(booking.getTrainId());
        dto.setTrainName(booking.getTrainName());
        dto.setSource(booking.getSource());
        dto.setDestination(booking.getDestination());
        dto.setDepartureTime(booking.getDepartureTime());
        dto.setClassName(booking.getClassName());
        dto.setJourneyDate(booking.getJourneyDate());
        dto.setBookingDate(booking.getBookingDate());
        dto.setNumberOfSeats(booking.getNumberOfSeats());
        dto.setFarePerSeat(booking.getFarePerSeat());
        dto.setTotalFare(booking.getTotalFare());
        dto.setBookingStatus(booking.getBookingStatus());
        // Convert passengers
        dto.setPassengers(
                booking.getPassengers()
                        .stream()
                        .map(this::toPassengerDTO)
                        .collect(Collectors.toList()));
        return dto;
    }

    //  Generate PNR Number
    private String generatePNR() {
        return "PNR" + System.currentTimeMillis();
    }

    // Generate Seat Number
    private String generateSeatNumber(
            String className, int index) {
        return className.substring(0, 1) + index;
        // G1, G2 for GENERAL
        // S1, S2 for SLEEPER
        // A1, A2 for AC
    }

    //  Book Ticket
    public BookingResponseDTO bookTicket(
            BookingRequestDTO requestDTO) {

        // Step 1: Check if passengers count
        // matches numberOfSeats
        if (requestDTO.getPassengers().size()
                != requestDTO.getNumberOfSeats()) {
            throw new RuntimeException(
                    "Passenger count must match number of seats!");
        }

        // Step 2: Check seat availability
        // via Feign Client → Train Service
        boolean isAvailable = trainServiceClient
                .checkAvailability(
                        requestDTO.getTrainId(),
                        requestDTO.getClassName());

        if (!isAvailable) {
            throw new RuntimeException(
                    "Seats not available for selected class!");
        }

        // Step 3: Get train details
        // via Feign Client → Train Service
        TrainResponseDTO train = trainServiceClient
                .getTrainById(requestDTO.getTrainId());

        // Step 4: Get fare for selected class
        // via Feign Client → Train Service
        double farePerSeat = trainServiceClient
                .getFare(
                        requestDTO.getTrainId(),
                        requestDTO.getClassName());

        // Step 5: Calculate total fare
        double totalFare = farePerSeat
                * requestDTO.getNumberOfSeats();

        // Step 6: Create and save Booking
        Booking booking = new Booking();
        booking.setPnrNumber(generatePNR());
        booking.setUserId(requestDTO.getUserId());
        booking.setTrainId(requestDTO.getTrainId());
        booking.setTrainName(train.getTrainName());
        booking.setSource(train.getSource());
        booking.setDestination(train.getDestination());
        booking.setDepartureTime(train.getDepartureTime());
        booking.setClassName(requestDTO.getClassName());
        booking.setJourneyDate(requestDTO.getJourneyDate());
        booking.setBookingDate(LocalDate.now());
        booking.setNumberOfSeats(requestDTO.getNumberOfSeats());
        booking.setFarePerSeat(farePerSeat);
        booking.setTotalFare(totalFare);
        booking.setBookingStatus("CONFIRMED");

        Booking savedBooking = bookingRepository.save(booking);

        // Step 7: Save Passengers with seat numbers
        List<Passenger> passengers = requestDTO
                .getPassengers()
                .stream()
                .map((PassengerDTO passengerDTO) -> {
                    Passenger passenger = new Passenger();
                    passenger.setPassengerName(
                            passengerDTO.getPassengerName());
                    passenger.setPassengerAge(
                            passengerDTO.getPassengerAge());
                    passenger.setPassengerGender(
                            passengerDTO.getPassengerGender());
                    // Generate seat number
                    passenger.setSeatNumber(
                            generateSeatNumber(
                                    requestDTO.getClassName(),
                                    requestDTO.getPassengers()
                                            .indexOf(passengerDTO) + 1));
                    passenger.setBooking(savedBooking);
                    return passengerRepository.save(passenger);
                })
                .collect(Collectors.toList());

        savedBooking.setPassengers(passengers);

        // Step 8: Update seat count in Train Service
        // via Feign Client
        trainServiceClient.updateSeatCount(
                requestDTO.getTrainId(),
                requestDTO.getClassName(),
                requestDTO.getNumberOfSeats());

        return toResponseDTO(savedBooking);
    }

    //  Get Booking by ID
    public BookingResponseDTO getBookingById(Long bookingId) {
        Booking booking = bookingRepository
                .findById(bookingId)
                .orElseThrow(() ->
                        new RuntimeException("Booking not found!"));
        return toResponseDTO(booking);
    }

    //  Get Booking by PNR
    public BookingResponseDTO getBookingByPNR(String pnr) {
        Booking booking = bookingRepository
                .findByPnrNumber(pnr)
                .orElseThrow(() ->
                        new RuntimeException("PNR not found!"));
        return toResponseDTO(booking);
    }

    //  Get All Bookings by User
    public List<BookingResponseDTO> getBookingsByUser(
            Long userId) {
        return bookingRepository
                .findByUserId(userId)
                .stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    //  Get All Bookings (Admin)
    public List<BookingResponseDTO> getAllBookings() {
        return bookingRepository
                .findAll()
                .stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    //  Cancel Booking
    public BookingResponseDTO cancelBooking(String pnr) {
        Booking booking = bookingRepository
                .findByPnrNumber(pnr)
                .orElseThrow(() ->
                        new RuntimeException("PNR not found!"));

        // Check if already cancelled
        if (booking.getBookingStatus()
                .equals("CANCELLED")) {
            throw new RuntimeException(
                    "Booking already cancelled!");
        }

        // Update status to CANCELLED
        booking.setBookingStatus("CANCELLED");
        bookingRepository.save(booking);

        // Add seats back to Train Service
        trainServiceClient.updateSeatCount(
                booking.getTrainId(),
                booking.getClassName(),
                -booking.getNumberOfSeats()); // negative = add back

        return toResponseDTO(booking);
    }
}