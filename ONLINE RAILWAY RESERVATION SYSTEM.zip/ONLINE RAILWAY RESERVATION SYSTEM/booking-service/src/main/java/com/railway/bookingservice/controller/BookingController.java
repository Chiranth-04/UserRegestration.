package com.railway.bookingservice.controller;

import com.railway.bookingservice.dto.BookingRequestDTO;
import com.railway.bookingservice.dto.BookingResponseDTO;
import com.railway.bookingservice.service.BookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;

    //  Book Ticket
    // POST http://localhost:8083/api/bookings/book
    @PostMapping("/book")
    public BookingResponseDTO bookTicket(
            @RequestBody BookingRequestDTO requestDTO) {
        return bookingService.bookTicket(requestDTO);
    }

    //  Get Booking by ID
    // GET http://localhost:8083/api/bookings/1
    @GetMapping("/{bookingId}")
    public BookingResponseDTO getBookingById(
            @PathVariable Long bookingId) {
        return bookingService.getBookingById(bookingId);
    }

    //  Get Booking by PNR
    // GET http://localhost:8083/api/bookings/pnr/PNR123456
    @GetMapping("/pnr/{pnr}")
    public BookingResponseDTO getBookingByPNR(
            @PathVariable String pnr) {
        return bookingService.getBookingByPNR(pnr);
    }

    //  Get All Bookings by User
    // GET http://localhost:8083/api/bookings/user/1
    @GetMapping("/user/{userId}")
    public List<BookingResponseDTO> getBookingsByUser(
            @PathVariable Long userId) {
        return bookingService.getBookingsByUser(userId);
    }

    //  Get All Bookings (Admin)
    // GET http://localhost:8083/api/bookings/all
    @GetMapping("/all")
    public List<BookingResponseDTO> getAllBookings() {
        return bookingService.getAllBookings();
    }

    //  Cancel Booking
    // PUT http://localhost:8083/api/bookings/cancel/PNR123456
    @PutMapping("/cancel/{pnr}")
    public BookingResponseDTO cancelBooking(
            @PathVariable String pnr) {
        return bookingService.cancelBooking(pnr);
    }
}