package com.railway.bookingservice.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "passengers")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Passenger {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long passengerId;

    @Column(nullable = false)
    private String passengerName;

    @Column(nullable = false)
    private int passengerAge;

    @Column(nullable = false)
    private String passengerGender;

    // Auto generated seat number
    private String seatNumber;

    // Many Passengers belong to One Booking
    @ManyToOne
    @JoinColumn(name = "booking_id")
    private Booking booking;
}