package com.railway.bookingservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookingRequestDTO {

    // Who is booking
    private Long userId;

    // Which train
    private Long trainId;

    // Which class
    private String className;

    // Journey date
    private LocalDate journeyDate;

    // How many seats
    private int numberOfSeats;

    // Passenger details
    private List<PassengerDTO> passengers;
}