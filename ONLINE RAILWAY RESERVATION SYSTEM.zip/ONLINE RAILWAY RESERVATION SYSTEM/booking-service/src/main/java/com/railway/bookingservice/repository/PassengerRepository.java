package com.railway.bookingservice.repository;

import com.railway.bookingservice.entity.Passenger;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PassengerRepository
        extends JpaRepository<Passenger, Long> {

    // Find all passengers by booking
    List<Passenger> findByBookingBookingId(Long bookingId);
}