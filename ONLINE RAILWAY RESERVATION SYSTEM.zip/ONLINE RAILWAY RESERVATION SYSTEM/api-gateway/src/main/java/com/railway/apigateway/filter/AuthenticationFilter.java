package com.railway.apigateway.filter;

import com.railway.apigateway.util.JwtUtil;
import org.springframework.beans.factory.annotation
        .Autowired;
import org.springframework.cloud.gateway.filter
        .GatewayFilter;
import org.springframework.cloud.gateway.filter.factory
        .AbstractGatewayFilterFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
public class AuthenticationFilter extends
        AbstractGatewayFilterFactory<
                AuthenticationFilter.Config> {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private RouteValidator routeValidator;

    public AuthenticationFilter() {
        super(Config.class);
    }

    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {

            String path = exchange
                    .getRequest()
                    .getURI()
                    .getPath();

            //  Debug log
            System.out.println(
                    " Incoming request: " + path);

            //  Skip if public route
            if (routeValidator.isPublicRoute(
                    exchange.getRequest())) {
                System.out.println(
                        " Public route - passing: "
                                + path);
                return chain.filter(exchange);
            }

            System.out.println(
                    " Protected route - checking: "
                            + path);

            //  Check Authorization header
            if (!exchange.getRequest()
                    .getHeaders()
                    .containsKey(
                            HttpHeaders.AUTHORIZATION)) {
                System.out.println(
                        " No Authorization header!");
                exchange.getResponse()
                        .setStatusCode(
                                HttpStatus.UNAUTHORIZED);
                return exchange.getResponse()
                        .setComplete();
            }

            //  Extract token
            String authHeader = exchange
                    .getRequest()
                    .getHeaders()
                    .getFirst(HttpHeaders.AUTHORIZATION);

            if (authHeader == null ||
                    !authHeader
                            .startsWith("Bearer ")) {
                System.out.println(
                        " Invalid Bearer format!");
                exchange.getResponse()
                        .setStatusCode(
                                HttpStatus.UNAUTHORIZED);
                return exchange.getResponse()
                        .setComplete();
            }

            String token = authHeader.substring(7);

            //  Validate token
            if (!jwtUtil.validateToken(token)) {
                System.out.println(
                        " Token validation failed!");
                exchange.getResponse()
                        .setStatusCode(
                                HttpStatus.UNAUTHORIZED);
                return exchange.getResponse()
                        .setComplete();
            }

            System.out.println(
                    " Token valid for: " +
                            jwtUtil.getEmailFromToken(token));

            //  Forward user info to services
            exchange = exchange.mutate()
                    .request(exchange.getRequest()
                            .mutate()
                            .header("X-User-Email",
                                    jwtUtil.getEmailFromToken(
                                            token))
                            .header("X-User-Role",
                                    jwtUtil.getRoleFromToken(
                                            token))
                            .header("X-User-Id",
                                    String.valueOf(
                                            jwtUtil
                                                    .getUserIdFromToken(
                                                            token)))
                            .build())
                    .build();

            return chain.filter(exchange);
        };
    }

    public static class Config {
    }
}