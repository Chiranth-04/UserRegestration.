package com.railway.apigateway.filter;

import org.springframework.http.server.reactive
        .ServerHttpRequest;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class RouteValidator {

    // ✅ Public routes - No token needed
    public static final List<String> PUBLIC_ROUTES =
            List.of(
                    "/api/auth/register",
                    "/api/auth/login",
                    "/api/auth/validate",
                    "/api/users/register",   // ✅ Add this!
                    "/api/trains/all",
                    "/api/trains/search"
            );

    public boolean isPublicRoute(
            ServerHttpRequest request) {

        String path = request
                .getURI()
                .getPath();

        System.out.println(
                "🔍 Checking path: " + path);

        boolean isPublic = PUBLIC_ROUTES
                .stream()
                .anyMatch(route ->
                        path.contains(route));

        System.out.println(
                isPublic
                        ? "✅ Is public route"
                        : "🔒 Is protected route");

        return isPublic;
    }
}