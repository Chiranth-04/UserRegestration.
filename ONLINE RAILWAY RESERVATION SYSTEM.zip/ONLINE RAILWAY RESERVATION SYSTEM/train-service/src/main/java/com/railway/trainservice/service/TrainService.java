package com.railway.trainservice.service;

import com.railway.trainservice.dto.TrainClassDTO;
import com.railway.trainservice.dto.TrainRequestDTO;
import com.railway.trainservice.dto.TrainResponseDTO;
import com.railway.trainservice.entity.Train;
import com.railway.trainservice.entity.TrainClass;
import com.railway.trainservice.repository.TrainClassRepository;
import com.railway.trainservice.repository.TrainRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TrainService {

    private final TrainRepository trainRepository;
    private final TrainClassRepository trainClassRepository;

    // Convert TrainClass Entity → DTO
    private TrainClassDTO toClassDTO(TrainClass trainClass) {
        TrainClassDTO dto = new TrainClassDTO();
        dto.setClassId(trainClass.getClassId());
        dto.setClassName(trainClass.getClassName());
        dto.setFare(trainClass.getFare());
        dto.setTotalSeats(trainClass.getTotalSeats());
        dto.setAvailableSeats(trainClass.getAvailableSeats());
        return dto;
    }

    //  Convert Train Entity → ResponseDTO
    private TrainResponseDTO toResponseDTO(Train train) {
        TrainResponseDTO dto = new TrainResponseDTO();
        dto.setTrainId(train.getTrainId());
        dto.setTrainName(train.getTrainName());
        dto.setTrainNumber(train.getTrainNumber());
        dto.setSource(train.getSource());
        dto.setDestination(train.getDestination());
        dto.setDepartureTime(train.getDepartureTime());
        dto.setArrivalTime(train.getArrivalTime());
        dto.setStatus(train.getStatus());

        // Convert each class
         dto.setTrainClasses(
                train.getTrainClasses()
                        .stream()
                        .map(this::toClassDTO)
                        .collect(Collectors.toList()));
        return dto;
    }

    //  Add Train with Classes
    public TrainResponseDTO addTrain(TrainRequestDTO requestDTO) {
        if (trainRepository.existsByTrainNumber(
                requestDTO.getTrainNumber())) {
            throw new RuntimeException("Train number already exists!");
        }

        // Save Train first
        Train train = new Train();
        train.setTrainName(requestDTO.getTrainName());
        train.setTrainNumber(requestDTO.getTrainNumber());
        train.setSource(requestDTO.getSource());
        train.setDestination(requestDTO.getDestination());
        train.setDepartureTime(requestDTO.getDepartureTime());
        train.setArrivalTime(requestDTO.getArrivalTime());
        train.setStatus(requestDTO.getStatus());
        Train savedTrain = trainRepository.save(train);

        // Save each class for this train
        List<TrainClass> trainClasses = requestDTO.getTrainClasses()
                .stream()
                .map(classDTO -> {
                    TrainClass trainClass = new TrainClass();
                    trainClass.setClassName(classDTO.getClassName());
                    trainClass.setFare(classDTO.getFare());
                    trainClass.setTotalSeats(classDTO.getTotalSeats());
                    trainClass.setAvailableSeats(
                            classDTO.getAvailableSeats());
                    trainClass.setTrain(savedTrain);
                    return trainClassRepository.save(trainClass);
                })
                .collect(Collectors.toList());

        savedTrain.setTrainClasses(trainClasses);
        return toResponseDTO(savedTrain);
    }

    //  Get Train by ID
    public TrainResponseDTO getTrainById(Long id) {
        Train train = trainRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Train not found!"));
        return toResponseDTO(train);
    }

    // Get All Trains
    public List<TrainResponseDTO> getAllTrains() {
        return trainRepository.findAll()
                .stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    //  Search Trains - source and destination
    public List<TrainResponseDTO> searchTrains(
            String source, String destination) {
        return trainRepository
                .findBySourceAndDestination(source, destination)
                .stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    //  Check Availability by Class
    public boolean checkAvailability(Long trainId, String className) {
        TrainClass trainClass = trainClassRepository
                .findByTrainTrainIdAndClassName(trainId, className)
                .orElseThrow(() ->
                        new RuntimeException("Class not found!"));
        return trainClass.getAvailableSeats() > 0;
    }

    //  Get Fare by Class
    public double getFareByClass(Long trainId, String className) {
        TrainClass trainClass = trainClassRepository
                .findByTrainTrainIdAndClassName(trainId, className)
                .orElseThrow(() ->
                        new RuntimeException("Class not found!"));
        return trainClass.getFare();
    }

    // Update Seat Count
    // Called by Reservation Service via Feign
    public void updateSeatCount(
            Long trainId, String className, int count) {
        TrainClass trainClass = trainClassRepository
                .findByTrainTrainIdAndClassName(trainId, className)
                .orElseThrow(() ->
                        new RuntimeException("Class not found!"));

        if (trainClass.getAvailableSeats() < count) {
            throw new RuntimeException(
                    "Not enough seats available!");
        }
        // Reduce available seats
        trainClass.setAvailableSeats(
                trainClass.getAvailableSeats() - count);
        trainClassRepository.save(trainClass);
    }

    //  Delete Train
    public String deleteTrain(Long id) {
        Train train = trainRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Train not found!"));
        trainRepository.delete(train);
        return "Train deleted successfully!";
    }
}
