package com.railway.trainservice.repository;

import com.railway.trainservice.entity.TrainClass;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TrainClassRepository
        extends JpaRepository<TrainClass, Long> {

    // Find class by train id and class name
    Optional<TrainClass> findByTrainTrainIdAndClassName(
            Long trainId, String className);

    // Find all classes for a train
    List<TrainClass> findByTrainTrainId(Long trainId);
}