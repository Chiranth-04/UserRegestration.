package com.railway.trainservice.security;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation
        .Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation
        .method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation
        .web.builders.HttpSecurity;
import org.springframework.security.config.annotation
        .web.configuration.EnableWebSecurity;
import org.springframework.security.config.http
        .SessionCreationPolicy;
import org.springframework.security.web
        .SecurityFilterChain;
import org.springframework.security.web.authentication
        .UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthFilter jwtAuthFilter;

    @Bean
    public SecurityFilterChain filterChain(
            HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .sessionManagement(session -> session
                        .sessionCreationPolicy(
                                SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth

                        // ✅ PUBLIC
                        .requestMatchers(HttpMethod.GET,
                                "/api/trains/all",
                                "/api/trains/search")
                        .permitAll()

                        // ✅ ADMIN only
                        .requestMatchers(HttpMethod.POST,
                                "/api/trains/add")
                        .hasRole("ADMIN")

                        .requestMatchers(HttpMethod.DELETE,
                                "/api/trains/delete/**")
                        .hasRole("ADMIN")

                        // ✅ PASSENGER + ADMIN
                        .requestMatchers(HttpMethod.GET,
                                "/api/trains/**")
                        .hasAnyRole("PASSENGER", "ADMIN")

                        .requestMatchers(HttpMethod.PUT,
                                "/api/trains/update-seats/**")
                        .hasAnyRole("PASSENGER", "ADMIN")

                        .anyRequest().authenticated())
                .addFilterBefore(
                        jwtAuthFilter,
                        UsernamePasswordAuthenticationFilter
                                .class);

        return http.build();
    }
}