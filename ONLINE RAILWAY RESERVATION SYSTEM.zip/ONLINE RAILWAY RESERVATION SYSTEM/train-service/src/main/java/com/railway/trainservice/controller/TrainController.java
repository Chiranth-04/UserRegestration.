package com.railway.trainservice.controller;

import com.railway.trainservice.dto.TrainRequestDTO;
import com.railway.trainservice.dto.TrainResponseDTO;
import com.railway.trainservice.service.TrainService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/trains")
@RequiredArgsConstructor
public class TrainController {

    private final TrainService trainService;

    // Add Train
    // POST http://localhost:8082/api/trains/add
    @PostMapping("/add")
    public TrainResponseDTO addTrain(
            @RequestBody TrainRequestDTO dto) {
        return trainService.addTrain(dto);
    }

    //  Get by ID
    // GET http://localhost:8082/api/trains/1
    @GetMapping("/{id}")
    public TrainResponseDTO getTrainById(
            @PathVariable Long id) {
        return trainService.getTrainById(id);
    }

    // Get All
    // GET http://localhost:8082/api/trains/all
    @GetMapping("/all")
    public List<TrainResponseDTO> getAllTrains() {
        return trainService.getAllTrains();
    }

    // Search
    // GET http://localhost:8082/api/trains/search
    //     ?source=Chennai&destination=Mumbai
    @GetMapping("/search")
    public List<TrainResponseDTO> searchTrains(
            @RequestParam String source,
            @RequestParam String destination) {
        return trainService.searchTrains(source, destination);
    }

    // Check Availability by Class
    // GET http://localhost:8082/api/trains/availability/1?className=SLEEPER
    @GetMapping("/availability/{trainId}")
    public boolean checkAvailability(
            @PathVariable Long trainId,
            @RequestParam String className) {
        return trainService.checkAvailability(trainId, className);
    }

    // Get Fare by Class
    // GET http://localhost:8082/api/trains/fare/1?className=SLEEPER
    @GetMapping("/fare/{trainId}")
    public double getFare(
            @PathVariable Long trainId,
            @RequestParam String className) {
        return trainService.getFareByClass(trainId, className);
    }

    // Update Seat Count
    // PUT http://localhost:8082/api/trains/update-seats/1
    //     ?className=SLEEPER&count=2
    @PutMapping("/update-seats/{trainId}")
    public String updateSeatCount(
            @PathVariable Long trainId,
            @RequestParam String className,
            @RequestParam int count) {
        trainService.updateSeatCount(trainId, className, count);
        return "Seats updated successfully!";
    }

    // Delete Train
    // DELETE http://localhost:8082/api/trains/delete/1
    @DeleteMapping("/delete/{id}")
    public String deleteTrain(
            @PathVariable Long id) {
        return trainService.deleteTrain(id);
    }
}