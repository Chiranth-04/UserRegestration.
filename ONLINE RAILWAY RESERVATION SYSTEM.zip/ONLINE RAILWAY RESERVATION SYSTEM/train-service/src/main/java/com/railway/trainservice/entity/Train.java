package com.railway.trainservice.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Entity
@Table(name = "trains")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Train {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long trainId;

    @Column(nullable = false)
    private String trainName;

    @Column(nullable = false, unique = true)
    private String trainNumber;

    @Column(nullable = false)
    private String source;

    @Column(nullable = false)
    private String destination;

    @Column(nullable = false)
    private String departureTime;

    @Column(nullable = false)
    private String arrivalTime;

    // ACTIVE, CANCELLED
    @Column(nullable = false)
    private String status;

    // One Train has Many Classes
    // SLEEPER, AC, GENERAL - each with own seats and fare
    @OneToMany(mappedBy = "train",
            cascade = CascadeType.ALL,
            fetch = FetchType.EAGER)
    private List<TrainClass> trainClasses;
}