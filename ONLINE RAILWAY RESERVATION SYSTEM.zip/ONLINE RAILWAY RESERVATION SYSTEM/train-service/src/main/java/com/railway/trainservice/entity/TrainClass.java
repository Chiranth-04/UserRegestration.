package com.railway.trainservice.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "train_classes")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TrainClass {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long classId;

    // SLEEPER, AC, GENERAL
    @Column(nullable = false)
    private String className;

    // Fare for this class
    @Column(nullable = false)
    private double fare;

    // Total seats for this class
    @Column(nullable = false)
    private int totalSeats;

    // Available seats for this class
    @Column(nullable = false)
    private int availableSeats;

    // Many Classes belong to One Train
    @ManyToOne
    @JoinColumn(name = "train_id")
    private Train train;
}