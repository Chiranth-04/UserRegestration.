package com.railway.trainservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TrainClassDTO {

    private Long classId;
    private String className;   // SLEEPER, AC, GENERAL
    private double fare;        // Fare for this class
    private int totalSeats;     // Total seats
    private int availableSeats; // Available seats
}