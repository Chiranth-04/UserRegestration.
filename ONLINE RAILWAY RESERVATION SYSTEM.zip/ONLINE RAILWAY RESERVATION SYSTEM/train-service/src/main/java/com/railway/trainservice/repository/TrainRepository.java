package com.railway.trainservice.repository;

import com.railway.trainservice.entity.Train;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TrainRepository extends JpaRepository<Train, Long> {

    // Search trains by source and destination
    List<Train> findBySourceAndDestination(
            String source,
            String destination);

    // Find by train number
    Optional<Train> findByTrainNumber(String trainNumber);

    // Check if train number exists
    boolean existsByTrainNumber(String trainNumber);
}