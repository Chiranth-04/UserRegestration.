package com.railway.authservice.controller;

import com.railway.authservice.dto.*;
import com.railway.authservice.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    // ✅ PUBLIC - Anyone can register
    // Always becomes PASSENGER
    @PostMapping("/register")
    public ResponseEntity<AuthResponseDTO> register(
            @RequestBody RegisterRequestDTO requestDTO) {
        return ResponseEntity.ok(
                authService.register(requestDTO));
    }

    // ✅ PUBLIC - Anyone can login
    @PostMapping("/login")
    public ResponseEntity<AuthResponseDTO> login(
            @RequestBody LoginRequestDTO loginDTO) {
        return ResponseEntity.ok(
                authService.login(loginDTO));
    }

    // ✅ ADMIN ONLY - Create another admin
    @PostMapping("/create-admin")
    public ResponseEntity<AuthResponseDTO> createAdmin(
            @RequestHeader("X-User-Role") String role,
            @RequestBody AdminCreateDTO adminCreateDTO) {

        // ✅ Check if requester is ADMIN
        if (!role.equals("ADMIN")) {
            return ResponseEntity
                    .status(403)
                    .build();
        }

        return ResponseEntity.ok(
                authService.createAdmin(adminCreateDTO));
    }

    // ✅ Validate Token
    @GetMapping("/validate")
    public ResponseEntity<Boolean> validate(
            @RequestParam String token) {
        return ResponseEntity.ok(
                authService.validateToken(token));
    }
}