package com.railway.authservice.config;

import com.railway.authservice.entity.User;
import com.railway.authservice.repository.UserRepository;
import lombok.RequiredArgsConstructor;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password
        .PasswordEncoder;

@Configuration
@RequiredArgsConstructor
public class DataInitializer {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Bean
    public CommandLineRunner initAdmin() {
        return args -> {

            //  Only create if not exists
            if (!userRepository.existsByEmail(
                    "superadmin@railway.com")) {

                User admin = new User();
                admin.setEmail(
                        "superadmin@railway.com");
                admin.setPassword(
                        passwordEncoder.encode(
                                "superadmin123"));
                admin.setRole("ADMIN");

                userRepository.save(admin);
                System.out.println(
                        " Super Admin created!");
                System.out.println(
                        " Email: superadmin@railway.com");
                System.out.println(
                        " Password: superadmin123");
            }
        };
    }
}