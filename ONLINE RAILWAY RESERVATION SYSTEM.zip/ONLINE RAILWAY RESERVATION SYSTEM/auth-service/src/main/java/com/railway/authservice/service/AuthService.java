package com.railway.authservice.service;

import com.railway.authservice.dto.*;
import com.railway.authservice.entity.User;
import com.railway.authservice.repository.UserRepository;
import com.railway.authservice.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password
        .PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    // ✅ Register - Always PASSENGER
    public AuthResponseDTO register(
            RegisterRequestDTO requestDTO) {

        if (userRepository.existsByEmail(
                requestDTO.getEmail())) {
            throw new RuntimeException(
                    "Email already registered!");
        }

        User user = new User();
        user.setEmail(requestDTO.getEmail());
        user.setPassword(passwordEncoder.encode(
                requestDTO.getPassword()));
        // ✅ Always PASSENGER - no choice!
        user.setRole("PASSENGER");

        User savedUser = userRepository.save(user);

        String token = jwtUtil.generateToken(
                savedUser.getEmail(),
                savedUser.getRole(),
                savedUser.getUserId());

        return new AuthResponseDTO(
                token,
                savedUser.getRole(),
                savedUser.getUserId(),
                savedUser.getEmail(),
                "Registration successful!");
    }

    // ✅ Login
    public AuthResponseDTO login(
            LoginRequestDTO loginDTO) {

        User user = userRepository
                .findByEmail(loginDTO.getEmail())
                .orElseThrow(() ->
                        new RuntimeException(
                                "User not found!"));

        if (!passwordEncoder.matches(
                loginDTO.getPassword(),
                user.getPassword())) {
            throw new RuntimeException(
                    "Invalid password!");
        }

        String token = jwtUtil.generateToken(
                user.getEmail(),
                user.getRole(),
                user.getUserId());

        return new AuthResponseDTO(
                token,
                user.getRole(),
                user.getUserId(),
                user.getEmail(),
                "Login successful!");
    }

    // ✅ Create Admin - Only callable by ADMIN
    public AuthResponseDTO createAdmin(
            AdminCreateDTO adminCreateDTO) {

        if (userRepository.existsByEmail(
                adminCreateDTO.getEmail())) {
            throw new RuntimeException(
                    "Email already registered!");
        }

        User admin = new User();
        admin.setEmail(adminCreateDTO.getEmail());
        admin.setPassword(passwordEncoder.encode(
                adminCreateDTO.getPassword()));
        // ✅ Force role to ADMIN
        admin.setRole("ADMIN");

        User savedAdmin = userRepository.save(admin);

        String token = jwtUtil.generateToken(
                savedAdmin.getEmail(),
                savedAdmin.getRole(),
                savedAdmin.getUserId());

        return new AuthResponseDTO(
                token,
                savedAdmin.getRole(),
                savedAdmin.getUserId(),
                savedAdmin.getEmail(),
                "Admin created successfully!");
    }

    // ✅ Validate Token
    public boolean validateToken(String token) {
        return jwtUtil.validateToken(token);
    }
}