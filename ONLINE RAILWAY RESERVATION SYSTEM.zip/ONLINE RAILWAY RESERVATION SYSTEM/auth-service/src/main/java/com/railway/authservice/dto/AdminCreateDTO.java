package com.railway.authservice.dto;

import lombok.Data;

@Data
public class AdminCreateDTO {
    private String email;
    private String password;
}